# placeholder: carga YAML desde S3 y responde FAQs
