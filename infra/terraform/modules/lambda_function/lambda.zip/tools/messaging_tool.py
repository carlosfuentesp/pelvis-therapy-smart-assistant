# placeholder: envío WhatsApp via AWS End User Messaging Social (boto3 client social-messaging)
