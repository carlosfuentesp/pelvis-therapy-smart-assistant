# placeholder: create/update/delete events con google-api-python-client
