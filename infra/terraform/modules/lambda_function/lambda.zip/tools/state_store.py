# placeholder: CRUD en DynamoDB para estado conversación y confirmaciones
